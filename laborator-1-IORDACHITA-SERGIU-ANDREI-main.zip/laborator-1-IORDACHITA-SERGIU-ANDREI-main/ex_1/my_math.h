#ifndef MY_MATH_H
#define MY_MATH_H

int sum(int a, int b);
int multiply(int a, int b);

#endif
