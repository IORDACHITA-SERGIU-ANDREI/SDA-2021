#include "my_math.h"

int sum(int a, int b)
{
   return a + b;
}

int multiply(int a, int b)
{
   return a * b;
}
